//  L3OCUnitTestResultFormatter.h
//  Created by Rob Rix on 2012-11-11.
//  Copyright (c) 2012 Rob Rix. All rights reserved.

#import <Lagrangian/L3TestResultFormatter.h>

@interface L3OCUnitTestResultFormatter : NSObject <L3TestResultFormatter>
@end
